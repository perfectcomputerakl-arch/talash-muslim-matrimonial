package com.barar.salattime;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.view.KeyEvent;
import android.widget.Toast;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.webkit.JavascriptInterface;
import android.view.Surface;

import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity implements SensorEventListener {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int LOCATION_REQUEST = 1002;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private boolean compassRunning = false;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 1003;
    private int prayerNotificationId = 2000;

    private WebView printWebView;

    public class ToolsBridge {
        @JavascriptInterface public void printHtml(String html, String title) {
            runOnUiThread(() -> {
                WebView pv = new WebView(MainActivity.this);
                pv.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView v, String u) {
                        android.print.PrintManager pm = (android.print.PrintManager) getSystemService(Context.PRINT_SERVICE);
                        if (pm != null) pm.print(title, v.createPrintDocumentAdapter(title), new android.print.PrintAttributes.Builder().build());
                    }
                });
                printWebView = pv;
                pv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            });
        }
        @JavascriptInterface public void shareText(String title, String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, title);
                i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, title));
            });
        }
    }

    public class CompassBridge {
        @JavascriptInterface public boolean start() { return startCompass(); }
        @JavascriptInterface public void stop() { stopCompass(); }
    }

    public class PrayerAlertsBridge {
        @JavascriptInterface public void schedule(String json) { AlarmScheduler.scheduleAll(getApplicationContext(), json); }
        @JavascriptInterface public boolean canExact() { return AlarmScheduler.canExact(getApplicationContext()); }
        @JavascriptInterface public void requestPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
                }
            });
        }
        @JavascriptInterface public void notify(String title, String message) {
            runOnUiThread(() -> showPrayerNotification(title, message));
        }
    }

    public class RingtoneBridge {
        @JavascriptInterface public String setCallRingtone(String name, String mime, String base64) {
            try {
                if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.System.canWrite(MainActivity.this)) {
                    Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    return "NEED_PERMISSION";
                }
                if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1004));
                    return "NEED_STORAGE";
                }
                byte[] data = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
                String mt = (mime == null || mime.length() == 0) ? "audio/wav" : mime;
                String ext = mt.contains("mpeg") ? ".mp3" : (mt.contains("ogg") ? ".ogg" : ((mt.contains("mp4") || mt.contains("aac")) ? ".m4a" : ".wav"));
                String fname = "barar_ringtone_" + System.currentTimeMillis() + ext;
                String title = (name == null || name.length() == 0) ? "Barar Ringtone" : name;
                android.content.ContentResolver cr = getContentResolver();
                android.content.ContentValues v = new android.content.ContentValues();
                v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fname);
                v.put(android.provider.MediaStore.MediaColumns.TITLE, title);
                v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mt);
                v.put(android.provider.MediaStore.Audio.Media.IS_RINGTONE, true);
                Uri uri;
                if (Build.VERSION.SDK_INT >= 29) {
                    v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_RINGTONES);
                    uri = cr.insert(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) return "ERROR:could not create ringtone entry";
                    java.io.OutputStream os = cr.openOutputStream(uri);
                    os.write(data);
                    os.close();
                } else {
                    java.io.File dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_RINGTONES);
                    dir.mkdirs();
                    java.io.File f = new java.io.File(dir, fname);
                    java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
                    fo.write(data);
                    fo.close();
                    v.put(android.provider.MediaStore.MediaColumns.DATA, f.getAbsolutePath());
                    uri = cr.insert(android.provider.MediaStore.Audio.Media.getContentUriForPath(f.getAbsolutePath()), v);
                    if (uri == null) return "ERROR:could not create ringtone entry";
                }
                android.media.RingtoneManager.setActualDefaultRingtoneUri(MainActivity.this, android.media.RingtoneManager.TYPE_RINGTONE, uri);
                return "OK";
            } catch (Exception e) {
                return "ERROR:" + e.getMessage();
            }
        }
    }

    private void showPrayerNotification(String title, String message) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel("barar_prayer_alerts", "Prayer & Makrooh Alerts", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Prayer time and Makrooh time alerts");
            manager.createNotificationChannel(channel);
        }
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "barar_prayer_alerts")
                : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title == null ? "BARAR SALAT TIME" : title)
                .setContentText(message == null ? "Prayer time reminder" : message)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER);
        manager.notify(prayerNotificationId++, builder.build());
    }

    private boolean startCompass() {
        if (sensorManager == null) sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager == null) return false;
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if (rotationSensor == null) return false;
        if (!compassRunning) compassRunning = sensorManager.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_UI);
        return compassRunning;
    }

    private void stopCompass() {
        if (sensorManager != null && compassRunning) sensorManager.unregisterListener(this);
        compassRunning = false;
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() != Sensor.TYPE_ROTATION_VECTOR || webView == null) return;
        float[] rotation = new float[9];
        float[] orientation = new float[3];
        SensorManager.getRotationMatrixFromVector(rotation, event.values);
        int displayRotation = getWindowManager().getDefaultDisplay().getRotation();
        int axisX = SensorManager.AXIS_X, axisY = SensorManager.AXIS_Y;
        if (displayRotation == Surface.ROTATION_90) { axisX = SensorManager.AXIS_Y; axisY = SensorManager.AXIS_MINUS_X; }
        else if (displayRotation == Surface.ROTATION_180) { axisX = SensorManager.AXIS_MINUS_X; axisY = SensorManager.AXIS_MINUS_Y; }
        else if (displayRotation == Surface.ROTATION_270) { axisX = SensorManager.AXIS_MINUS_Y; axisY = SensorManager.AXIS_X; }
        float[] adjusted = new float[9];
        SensorManager.remapCoordinateSystem(rotation, axisX, axisY, adjusted);
        SensorManager.getOrientation(adjusted, orientation);
        final double heading = (Math.toDegrees(orientation[0]) + 360.0) % 360.0;
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("if(window.onNativeCompassHeading)onNativeCompassHeading(" + heading + ");", null); });
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(0, 48, 22));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(0, 15, 7));
        if (Build.VERSION.SDK_INT >= 26) getWindow().getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        setContentView(webView);
        webView.addJavascriptInterface(new CompassBridge(), "AndroidCompass");
        webView.addJavascriptInterface(new PrayerAlertsBridge(), "AndroidPrayerAlerts");
        webView.addJavascriptInterface(new ToolsBridge(), "AndroidTools");
        webView.addJavascriptInterface(new RingtoneBridge(), "AndroidRingtone");

        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setGeolocationEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.setWebViewClient(new WebViewClient() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && !"appassets.androidplatform.net".equals(uri.getHost())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
                }
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { fileCallback = null; Toast.makeText(MainActivity.this, "File picker open nahi hua", Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST && pendingGeoCallback != null) {
            boolean granted = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            pendingGeoCallback = null; pendingGeoOrigin = null;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override protected void onPause() {
        stopCompass();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.post(() -> webView.evaluateJavascript(
                "if(document.getElementById('qibla') && document.getElementById('qibla').classList.contains('show')) refreshQibla();", null));
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        stopCompass();
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
