/* Optional Urdu translation, same format as quran-data.js. */
window.QURAN_URDU=null;
